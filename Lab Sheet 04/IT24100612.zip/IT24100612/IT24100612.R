setwd("C:\\Users\\IT24100612\\Desktop\\IT24100612")

#Question 1
branch_data = read.table("Exercise.txt",header = TRUE, sep = ",")

#Question 2


#Question 3
boxplot(branch_data$Sales_X1,main="Box plot for Sales Distribution",horizontal = TRUE,outline =FALSE)

#Question 4
summary(branch_data$Advertising_X2)

#Question 5
get_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  outliers <- x[x < lb | x > ub]
  return(outliers)
}

# Check for outliers in Years_X3
get_outliers(branch_data$Years_X3)