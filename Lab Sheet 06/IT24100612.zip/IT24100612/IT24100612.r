#Question 1
#Binomial Distribution
#Method 1
1-pbinom(46,50,0.85,lower.tail=TRUE)
#Method 2
pbinom(46,50,0.85,lower.tail=FALSE)


#Question 2
#Random variable : Customer calls per Hour
#Poisson Distribution
dpois(15,12)