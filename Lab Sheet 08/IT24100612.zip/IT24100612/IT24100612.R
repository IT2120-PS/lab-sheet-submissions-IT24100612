setwd("C:\\Users\\IT24100612\\Desktop\\IT24100612")
weights <- scan("Exercise - LaptopsWeights.txt", skip = 1)


population_mean <- mean(weights)
population_sd <- sqrt(mean((weights - population_mean)^2))


population_mean
population_sd

set.seed(123)
sample_means <- numeric(25)
sample_sds <- numeric(25)

for (i in 1:25) {
  sample <- sample(weights, size = 6, replace = TRUE)
  sample_means[i] <- mean(sample)
  sample_sds[i] <- sd(sample)
}


mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

mean_of_sample_means
sd_of_sample_means

