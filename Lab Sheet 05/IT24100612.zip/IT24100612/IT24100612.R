setwd("C:\\Users\\IT24100612\\Desktop\\IT24100612")

#Question 2
Delivery_Times<-read.table("Exercise - Lab 05.txt",header = TRUE)

#Question 3
histogram<-hist(Delivery_Times$Delivery_Time_.minutes.,main="Histogram of the Delivery Times",breaks=seq(20,70,length=10),right=TRUE)

#Question 4
freq<- hist(delivery_times$Delivery_Time_.minutes.,
            breaks = seq(20,70, length.out = 10),
            right = FALSE,
            plot = FALSE)

cum_freq<- cumsum(freq$counts)


plot(freq$breaks[-1],
     cum_freq,
     type = "l",
     main = "Cumulative Frequency Polygon",
     xlab = "Delivery Time",
     ylab = "Cumulative Freqency",
     ylim = c(0, max(cum_freq)))

grid()

